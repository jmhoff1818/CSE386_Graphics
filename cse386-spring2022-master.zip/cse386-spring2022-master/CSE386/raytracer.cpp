/****************************************************
 * 2016-2022 Eric Bachmann and Mike Zmuda
 * All Rights Reserved.
 * NOTICE:
 * Dissemination of this information or reproduction
 * of this material is prohibited unless prior written
 * permission is granted.
 ****************************************************/
#include "raytracer.h"
#include "ishape.h"
#include "io.h"

 /**
  * @fn	RayTracer::RayTracer(const color &defa)
  * @brief	Constructs a raytracers.
  * @param	defa	The clear color.
  */

RayTracer::RayTracer(const color& defa)
	: defaultColor(defa) {
}

/**
 * @fn	void RayTracer::raytraceScene(FrameBuffer &frameBuffer, int depth, const IScene &theScene) const
 * @brief	Raytrace scene
 * @param [in,out]	frameBuffer	Framebuffer.
 * @param 		  	depth	   	The current depth of recursion.
 * @param 		  	theScene   	The scene.
 */

void RayTracer::raytraceScene(FrameBuffer& frameBuffer, int depth,
	const IScene& theScene, int startY, int vpHeight, int startX, int vpWidth) const {
	const RaytracingCamera& camera = *theScene.camera;
	const vector<VisibleIShapePtr>& objs = theScene.opaqueObjs;
	const vector<TransparentIShapePtr>& objsT = theScene.transparentObjs;
	const vector<PositionalLightPtr>& lights = theScene.lights;


	int N = 3; // NxN anti-aliasing. 1 is for normal render
	for (int y = startY; y < startY + vpHeight; ++y) {
		for (int x = startX; x < startX + vpWidth; ++x) {
			DEBUG_PIXEL = (x == xDebug && y == yDebug);
			if (DEBUG_PIXEL) {
				cout << "";
			}
			
			/* CSE 386 - todo  */
			//const VisibleIShape& firstVisibleShape = *theScene.opaqueObjs[0];
			//const IShape& firstShape = *firstVisibleShape.shape;
			//firstShape.findClosestIntersection(ray, hit);

			Ray ray = camera.getRay(x, y);

			OpaqueHitRecord hit;
			VisibleIShape::findIntersection(ray, theScene.opaqueObjs, hit);

			TransparentHitRecord transHit;
			TransparentIShape::findIntersection(ray, theScene.transparentObjs, transHit);

			color opaque = black;
			color sum = black;
			// Opaque Objects
			if (hit.t != FLT_MAX) {
				if (glm::dot(ray.dir, hit.normal) > 0) {
					// A Back Face is being hit
					hit.normal = -hit.normal;
				}

				//opaque = theScene.lights[0]->illuminate(hit.interceptPt, hit.normal, hit.material, camera.getFrame(), false);
				//frameBuffer.setColor(x, y, opaque);

				// Use All Lights
				for (unsigned int i = 0; i < theScene.lights.size(); i++) {
					const PositionalLight& L = *theScene.lights[i];
					bool shadowed = L.pointIsInAShadow(hit.interceptPt, hit.normal, theScene.opaqueObjs, camera.getFrame());
					//bool shadowed = false;
					opaque += L.illuminate(hit.interceptPt, hit.normal, hit.material, camera.getFrame(), shadowed);
				}
				frameBuffer.setColor(x, y, opaque);

				// Apply Texture if Applicable

			}
			// Transparent Objects
			if (transHit.t != FLT_MAX) {
				if (hit.t == FLT_MAX) {
					color trans = (1 - transHit.alpha) * defaultColor + transHit.alpha * transHit.transColor;
					frameBuffer.setColor(x, y, trans);
				}
				else if (transHit.t < hit.t) {
					color finalcolor = (1 - transHit.alpha) * opaque + transHit.alpha * transHit.transColor;
					frameBuffer.setColor(x, y, finalcolor);
				}
			}
			/// /////////temp antiAliasing
			int antiAliasing = 1;
			
			// if on
			if (antiAliasing == 3) {
				//check all pixels around
					for (int xx = -1; xx < 2; xx++) {
						for (int yy = -1; yy <= 1; yy++) {
							// opaque = pixel at x + xx, y + yy

							// sum = opaque + sum / 2 (however you find the average of 2 colors)
						}
					}
				frameBuffer.setColor(x, y, sum);
			}


			if (hit.texture != nullptr /*&& hit.u > 0*/) {

				color texel = hit.texture->getPixelUV(hit.u, hit.v);
				sum = (texel / 2.0) + (sum / 2.0);
				frameBuffer.setColor(x, y, sum);

			}
			frameBuffer.showAxes(x, y, ray, 0.25);			// Displays R/x, G/y, B/z axes
		}
	}
	frameBuffer.showColorBuffer();
}

color RayTracer::traceIndividualRay(const Ray& ray, const IScene& theScene, int recursionLevel, int depth) const
{
	return color();
}

/**
 * @fn	color RayTracer::traceIndividualRay(const Ray &ray,
 *											const IScene &theScene,
 *											int recursionLevel) const
 * @brief	Trace an individual ray.
 * @param	ray			  	The ray.
 * @param	theScene	  	The scene.
 * @param	recursionLevel	The recursion level.
 * @return	The color to be displayed as a result of this ray.
 */

color RayTracer::traceIndividualRay(const Ray& ray, const IScene& theScene, int recursionLevel) const {
	/* CSE 386 - todo  */
	// This might be a useful helper function.
	return black;
}